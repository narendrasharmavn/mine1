<?php
include 'connectDB.php';



$postdata = file_get_contents("php://input");

$request = json_decode($postdata);
$kidsmealqty = $request->kidsmealqty;
$dateofvisit = $request->dateofvisit;
//echo "kidsmealqty : ".$kidsmealqty."<br>";
//echo "this is:".$request->obj[0]->packageid."\n";
$adultqty=0;
$childqty=0;
$adultticketprice=0;
$childticketprice=0;
$kidmealprice=0;
$internetcharges=0;
$servicetax=0;
$swachcess=0;
$krishicess=0;
$kidmealtax=0;
$total=0;
$vendorid=0;
 $sql1=mysqli_query($conn,"SELECT * FROM taxmaster");
    $result1=mysqli_fetch_assoc($sql1);
for($i=0;$i<count($request->obj);$i++){

    $packageid = $request->obj[$i]->packageid;
    $sql=mysqli_query($conn,"SELECT * FROM `tblpackages` p left join tblresorts r on r.resortid=p.resortid LEFT JOIN  tblvendors v on r.vendorid=v.vendorid WHERE p.packageid='$packageid'");
    $result=mysqli_fetch_assoc($sql);
    $adultqty =  $adultqty + $request->obj[$i]->adultqty;
    $childqty = $childqty + $request->obj[$i]->childqty;
    $adultticketprice = $adultticketprice + $request->obj[$i]->adultqty * $result['adultprice'];
    $childticketprice = $childticketprice + $request->obj[$i]->childqty * $result['childprice'];
    $internetcharges += ($adultticketprice + $childticketprice) * ($result1['servicetax'] / 100);
    $vendorid = $result['vendorid'];

    //echo "vendorid id is: ".$vendorid."\n";


}
    $sql3=mysqli_query($conn,"SELECT * FROM tblvendors WHERE vendorid='$vendorid'");
    //echo "SELECT * FROM tblvendors WHERE vendorid='$vendorid'\n";
    $result3=mysqli_fetch_assoc($sql3);
    $kidmealprice = $kidsmealqty * $result3['kidsmealprice'];
    //echo "kidsmeal price is: ".$kidmealprice."\n";
    //echo "kidsmeal price from database: ".$result3['kidsmealprice']."\n";
    $kidmealtax = $kidmealprice * ($result1['kidsmealtax'] / 100);
    $kidmealtax = round($kidmealtax,1);

    $internetcharges = round($internetcharges,1);
    
    $servicetax = $internetcharges * ($result1['servicetax'] / 100);
    $servicetax = round($servicetax,1);
    $swachcess = $internetcharges * ($result1['swachcess']/100);
    $swachcess = round($swachcess,1);
    $krishicess = $internetcharges * ($result1['krishicess']/100);
     $krishicess = round($krishicess,1);
    $total = $adultticketprice + $childticketprice + $kidmealprice + $internetcharges + $servicetax + $kidmealtax + $swachcess + $krishicess;
     $total = round($total,2);
    //echo "\n Adult Qty : ".$adultqty."\n Child Qty : ".$childqty."\n Kid Meal Qty : ".$kidsmealqty."\n  Adult Ticket Price : ".$adultticketprice."\n Chicd Ticket Price : ".$childticketprice."\n kidmealprice : ".$kidmealprice;
    //echo "\n kidmealtax ".$kidmealtax;
   //echo "\n internetcharges ".$servicecharges."\n swachcess : ".$swachcess."\n krishicess : ".$krishicess."\n Total : ".$total;


   $calculatedTotal = array(
    "adultqty"  => $adultqty,
    "adultprice"  => $adultticketprice,
    "childqty"  => $childqty,
    "childprice"  => $childticketprice,
    "kidsmealqty"  => $kidsmealqty,
    "kidsmealprice"  => $kidmealprice,
    "internetcharges"  => $internetcharges,
    "servicetax"  => $servicetax,
    "swachcess"  => $swachcess,
    "krishicess" => $krishicess,
    "total" => $total
);




echo json_encode($calculatedTotal,true);


mysqli_close($conn);

?>