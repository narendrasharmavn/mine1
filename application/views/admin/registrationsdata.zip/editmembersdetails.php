<?php
 include 'header.php'; 
 ?>

				<section role="main" class="content-body">
					<header class="page-header">
						<h2>Edit</h2>
					
						<div class="right-wrapper pull-right">
							<ol class="breadcrumbs">
								<li>
									<a href="index.html">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>Member Details</span></li>
								
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>

					<!-- start: page -->
						<div class="row">
							<div class="col-lg-12">
								<section class="panel">
									<header class="panel-heading">
										<div class="panel-actions">
											<a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
											<a href="#" class="panel-action panel-action-dismiss" data-panel-dismiss></a>
										</div>
						
										<h2 class="panel-title">Member Details</h2>
									</header>
									<div class="panel-body">
										
										<?php 
								            echo form_open_multipart('Admin/submiteditmemberdetails',array('class' => 'form-horizontal'));
								        ?>

								         <?php echo $this->session->flashdata('success'); ?> 
								         <?php
								            $id = $_GET['id']; 
											//echo $id;
											$query = $this->db->query("SELECT * FROM register WHERE ID='$id'");
											$rows = $query->row(); 
											$name = $rows->name;
											$surname = $rows->lastname;
											$email = $rows->lemail;
											$gender = $rows->gender;
											$height = $rows->height;
											$cms = $rows->cms;
											$age = $rows->age;
											$tob = $rows->tob;
											$dob = $rows->dob;
											$dt = $dob." ".$tob;
											$pob = $rows->pob;
											$residing_country = $rows->residing_country;
											$residing_state = $rows->residing_state;
											$native_district = $rows->native_district;
											$maritalstatus = $rows->maritalstatus;
											$caste = $rows->caste;
											$subcaste = $rows->subcaste;
											$religions = $rows->religion;
											$birthstars = $rows->birthstar;
											$padam = $rows->padam;
											$rasi = $rows->raasi;
											$gothram = $rows->gothram;
											$edu_type = $rows->education_type;
											$edu = $rows->education;
											$occ = $rows->occupation;
											$occ_type = $rows->occupation_type;
											$occupation_details = $rows->occupation_details;
											$income = $rows->income;
											$property = $rows->property;
                                            $address = $rows->address;
                                            $phone = $rows->phone;
                                            $altphn = $rows->alt_phone;
                                            $bro = $rows->brothers;
                                            $mbro = $rows->marriedbrothers;
                                            $sis = $rows->sisters;
                                            $msis = $rows->marriedsisters;
                                            $incometype = $rows->incometype;
                                            $property_price_type = $rows->property_price_type;
                                            $fathername = $rows->fathername;
                                            $fatheroccupation = $rows->fatheroccupation;
                                            $mothername = $rows->mothername;
                                            $motheroccupation = $rows->motheroccupation;
                                            $village = $rows->village;
                                            $mandal = $rows->mandal;
                                            $paymentmode = $rows->paymentmode;
                                            $amount = $rows->amount;

											$sql = $this->db->query("SELECT * FROM photos WHERE email='$email'");
											$rows = $query->row();
								         ?>
											<div class="form-group">
												<input type="hidden" class="form-control" name="uid" id="uid"  value="<?php echo $id; ?>">
								                <label for="inputEmail3" class="col-sm-2 control-label">Name</label>
								                <div class="col-sm-3">
								                  <input type="text" class="form-control" name="fname" id="fname" placeholder="Name" value="<?php echo $name; ?>">
								                </div>
								                <label for="inputPassword3" class="col-sm-2 control-label">Surname</label>
								                <div class="col-sm-3">
								                  <input type="text" class="form-control" name="lname" id="lname" placeholder="Surname" value="<?php echo $surname; ?>">
								                </div>
							                </div>

							                <div class="form-group">
								                <label for="inputEmail3" class="col-sm-2 control-label">Email</label>
								                <div class="col-sm-3">
								                  <input type="text" class="form-control" name="email" id="email" placeholder="Email" value="<?php echo $email; ?>" onkeyup='check_email()' onpaste='check_email()'>
								                  <div id="email"></div>
								                  <span class="text-danger"><?php echo form_error('email'); ?></span>
								                </div>
								                <label for="inputPassword3" class="col-sm-2 control-label">Gender</label>
								                <div class="col-md-1 col-sm-2">
								                  <label class="radio-inline">
								                    <input type="radio" name="gender" id="male" value="Male" <?php if($gender=="Male"){ echo "checked"; } ?>> Male
								                  </label>
										        </div>
								                <div class="col-md-1 col-sm-2">
								                  <label class="radio-inline">
								                    <input type="radio" name="gender" id="female" value="Female" <?php if($gender=="Female"){ echo "checked"; } ?>> Female
								                  </label>
								                </div> 
							                </div>

							                <div class="form-group">
								                <label for="inputEmail3" class="col-sm-2 control-label">Birthplace</label>
								                <div class="col-sm-3">
								                  <input type="text" class="form-control" name="birthplace" id="birthplace" placeholder="Birthplace" value="<?php echo $pob; ?>">
								                </div>
								                <label for="inputPassword3" class="col-sm-2 control-label">Date & Time Of Birth</label>
								                <div class="col-sm-3">
								                  <input type="text" id="demo1" name="dob" class="form-control" maxlength="25" size="25" value="<?php echo $dt; ?>"/>
								                    <img src="<?php echo base_url();  ?>assets/img/calendarimages/cal.gif" onclick="javascript:NewCssCal ('demo1','MMddyyyy','dropdown',true,'12',true)"
								                    style="float: right;margin-top: -24px;margin-right: 10px;"/>
								                </div>
							                </div>
											
											<div class="form-group">
												<label class="col-md-3 control-label" for="inputDefault">Height</label>
												<div class="col-md-2">
													<select class="form-control"  name="height" id="height" onclick="centerSelectedOption(this.value)" onChange="convert_FTtoCM(this.value)">
									                    <option value="0" <?php echo  set_select('height', '0'); ?>>-Select-</option>
									                    <?php
									                        $arr = array(4,5,6);
										                    foreach($arr as $ft)
										                    {
										                        for($inch=0;$inch<=11;$inch++)
										                        {
										                            if($inch<10)
										                            {
										                              $inch_val = '0'.$inch;
										                            }
										                            else
										                            {
										                              $inch_val = $inch;
										                            }
										                            $ht_val = $ft.'.'.$inch_val;
										                            $ht_val_old = $ft.'.'.$inch;
										                            $ht_disp = $ft.'\' '.$inch.'&quot;';
										                            if($height==$ht_val||$height==$ht_val_old)
										                            {
										                              echo '<option value="'.$ht_val.'" selected="selected">'.$ht_disp.'inches</option>';
										                            }
										                            else
										                            {
										                              echo '<option value="'.$ht_val.'">'.$ht_disp.'</option>';
										                            }
										                        }
										                    }
									                    ?>
									                </select>
												</div>
												<div class="col-sm-1"><b>OR</b></div>
									                <div class="col-sm-2">
									                 <select class="form-control" name="CMS" id="CMS" onChange="convert_CMtoFT(this.value)">
									                    <option value="0" <?php echo  set_select('CMS', '0'); ?>>-Cms-</option>
									                    <?php
										                  for($i=137;$i<=213;$i++)
										                  {
										                    if($cms==$i){
										                      $checked="selected";
										                    }else{
										                      $checked="";
										                    }
										                    echo '<option value="'.$i.'"'. $checked.'>'.$i.'cms</option>';
										                  }
										                ?>
									                  </select>
									            </div>
											</div>

											<div class="form-group">
								                <label for="inputEmail3" class="col-sm-2 control-label">Country</label>
								                <div class="col-sm-3">
								                    <select class="form-control" name="country" id="country"  onchange="ajaxFunction(),showValue(this.value),showState()">
									                    <option>Select</option>
									                    <?php 
									                    foreach ($countries->result() as $row)
									                    {               
									                        //echo $row->name;
									                    
									                    ?>
									                    <option value="<?php echo $row->name; ?>" <?php if($residing_country == $row->name ) { echo "Selected";}?>><?php echo $row->name; ?></option>
									                    <?php } ?>
								                    </select>
								                </div>
								                 
								                <label for="inputPassword3" class="col-sm-2 control-label">State</label>
								                <div class="col-sm-3">
								                    <select class="form-control" name="states" id="states" onchange="ajaxState()">
									                    <option>Select</option>
									                </select>
								                </div>
							                </div>

							                <div class="form-group">
							                	<label for="inputEmail3" class="col-sm-2 control-label">Districts</label>
								                <div class="col-sm-3">
								                    <select class="form-control" name="districts" id="districts" onchange="ajaxMandals()">
									                    <option>Select</option>
									                </select>
								                </div>
								                <label for="inputEmail3" class="col-sm-2 control-label">Mandals</label>
								                <div class="col-sm-3">
								                    <select class="form-control" name="mandals" id="mandals" >
									                    <option>Select</option>
									                </select>
								                </div>
							                </div>

							                <div class="form-group">
								                <label for="inputPassword3" class="col-sm-2 control-label">Villages</label>
								                <div class="col-sm-3">
								                    <input type="text" class="form-control" name="village" id="village" placeholder="Village" value="<?php echo $village; ?>">
								                </div>
								                <label for="inputPassword3" class="col-sm-2 control-label">Mobile Number</label>
								                <div class="col-sm-3">
								                  <input type="number" class="form-control" name="mobile" id="mobile" placeholder="Mobile" value="<?php echo $phone; ?>">
								                  
								                </div>
							                </div>

							                <div class="form-group">
								                <label for="inputEmail3" class="col-sm-2 control-label">Alternate Contact Number</label>
								                <div class="col-sm-3">
								                  <input type="number" class="form-control" name="anumber" id="anumber" placeholder="Alternate Number" value="<?php echo $altphn; ?>">
								                </div>
								                <label for="inputPassword3" class="col-sm-2 control-label">Marital Status</label>
								                <div class="col-sm-3">
								                    <select class="form-control" name="mstatus" id="mstatus">
								                      <option value="" <?php echo  set_select('mstatus', 'Select'); ?>>Select</option>
								                      <option value="UnMarried" <?php if($maritalstatus == "UnMarried") { echo "Selected"; }?>>UnMarried</option>
									                  <option value="Widow/Widower" <?php if($maritalstatus == "Widow/Widower") { echo "Selected"; }?>>Widow/Widower</option>
									                  <option value="Divorce" <?php if($maritalstatus == "Divorcee") { echo "Selected"; }?>>Divorce</option>
									                  <option value="Separated" <?php if($maritalstatus == "Separated") { echo "Selected"; }?>>Separated</option>
								                    </select>
								                </div>
							                </div>

							                <div class="form-group">
								                <label for="inputEmail3" class="col-sm-2 control-label">Religion</label>
								                <div class="col-sm-3">
								                    <select class="form-control" name="religion" id="religion" onchange="hideFields()">
									                    <option>Select</option>
									                    <?php 
									                    foreach ($religion->result() as $row)
									                    {               
									                        //echo $row->religion_name;
									                    
									                    ?>
									                    <option value="<?php echo $row->religion_name; ?>" <?php if($religions == $row->religion_name ) { echo "Selected";}?>><?php echo $row->religion_name; ?></option>
									                    <?php } ?>
								                    </select>
								                </div>
								                <label for="inputPassword3" class="col-sm-2 control-label">Caste</label>
								                <div class="col-sm-3">
								                    <select class="form-control" name="caste" id="caste">
								                      <option value="0" <?php echo  set_select('caste', '0'); ?>>Select</option>
								                      <option value="OC" <?php if($caste == "OC") { echo "Selected"; }?>>OC </option>
								                      <option value="BC" <?php if($caste == "BC") { echo "Selected"; }?>>BC </option>
								                      <option value="SC" <?php if($caste == "SC") { echo "Selected"; }?>>SC </option>
								                      <option value="ST" <?php if($caste == "ST") { echo "Selected"; }?>>ST </option>
								                    </select>
								                  
								                </div>
							                </div>

							                <div class="form-group">
								                <label for="inputEmail3" class="col-sm-2 control-label">SubCaste</label>
								                <div class="col-sm-3">
								                  <input type="text" class="form-control" name="scaste" id="scaste" placeholder="SubCaste" value="<?php echo $subcaste; ?>">
								                </div>
								                <div id="hgothram">
									                <label for="inputPassword3" class="col-sm-2 control-label">Gothram</label>
									                <div class="col-sm-3">
									                  <input type="text" class="form-control" name="gothram" id="gothram" placeholder="Gothram" value="<?php echo $gothram; ?>">
									                </div>
								                </div>
							                </div>

							                <div class="form-group" id="hbstar">
								                <label for="inputEmail3" class="col-sm-2 control-label">Birthstar</label>
								                <div class="col-sm-3">
								                    <select class="form-control" name="bstar" id="bstar" onChange="getAjaxRaasi(this.value)">
								                      <option>Select</option>
								                      <?php 
								                       foreach ($birthstar->result() as $bs)
								                      {               
								                          //echo $bs->name;
								                      ?>
								                      <option value="<?php echo $bs->s_birth_star; ?>" <?php if($birthstars == $bs->s_birth_star ) { echo "Selected";}?>><?php echo $bs->s_birth_star; ?></option>
								                      <?php } ?>
								                    </select>
								                </div>
								                <label for="inputPassword3" class="col-sm-2 control-label">Raasi</label>
								                <div class="col-sm-3" >
								                    <select class="form-control" name="raasi" id="raasi">
								                      <option>Select</option>
								                      <?php 
								                       foreach ($raasi->result() as $rs)
								                      {               
								                          //echo $rs->s_raasi;
								                      ?>
								                      <option value="<?php echo $rs->s_raasi; ?>" <?php if($rasi == $rs->s_raasi ) { echo "Selected";}?>><?php echo $rs->s_raasi; ?></option>
								                      <?php } ?>
								                    </select>
								                </div>
							                </div>

                                            <div class="form-group" id="hpadam">
								                <label for="inputEmail3" class="col-sm-2 control-label">Padam</label>
								                <div class="col-sm-3">
								                    <select class="form-control" name="padam" id="padam">
								                      <option value="0" <?php echo  set_select('padam', '0'); ?>>Select</option>
								                      <option value="N.A." <?php if($padam == "N.A.") { echo "Selected"; }?>>N.A. </option>
								                      <option value="First" <?php if($padam == "First") { echo "Selected"; }?>>First </option>
								                      <option value="Second" <?php if($padam == "Second") { echo "Selected"; }?>>Second </option>
								                      <option value="Third" <?php if($padam == "Third") { echo "Selected"; }?>>Third </option>
								                      <option value="Fourth" <?php if($padam == "Fourth") { echo "Selected"; }?>>Fourth </option>
								                    </select>
								                </div>
								                
							                </div>  
											
											
											
											<h3>Education & Occupation Details</h3>
											<hr>


											<div class="form-group">
								                <label for="inputEmail3" class="col-sm-2 control-label">Education Type</label>
								                <div class="col-sm-3">
								                  <select class="form-control" name="edtype" id="edtype" onchange="ajaxEducation(this.value)">
								                    <option value="0" <?php echo  set_select('edtype', '0'); ?> style="padding: 3px;border-bottom: solid 1px silver;">Select Education Type</option>
								                    <option style="padding: 3px;border-bottom: solid 1px silver;" value="any" <?php echo  set_select('edtype', 'any'); ?>>Any</option>
								                    <?php 
								                    foreach ($edtype->result() as $et)
								                    {               
								                      //echo $et->education_name;
								                    ?>
								                    <option value="<?php echo $et->education_table_id; ?>" <?php if($edu_type == $et->education_table_id ) { echo "Selected";}?> style="padding: 3px;border-bottom: solid 1px silver;" ><?php echo $et->education_name; ?></option>
								                    <?php } ?>
								                  </select>
								                </div>
								                <label for="inputPassword3" class="col-sm-2 control-label">Education</label>
								                <div class="col-sm-3">
								                    <select class="form-control education"  id="education" name="education">
									                  <option style="padding: 3px;border-bottom: solid 1px silver;">Select Education</option>
									                  <option style="padding: 3px;border-bottom: solid 1px silver;" value="any" <?php echo  set_select('education', 'any'); ?>>Any</option>
									                </select>
								                </div>
							                </div>

											<div class="form-group">
								                <label for="inputEmail3" class="col-sm-2 control-label">Occupation Type</label>
								                <div class="col-sm-3">
								                  <select class="form-control"  name="occptype" id="occptype">
								                    <option value="0" <?php echo  set_select('occptype', '0'); ?> style="padding: 3px;border-bottom: solid 1px silver;">Select Occupation</option>
								                    <option style="padding: 3px;border-bottom: solid 1px silver;" value="any" <?php echo  set_select('occptype', 'any'); ?>>Any</option>
								                    <?php 
								                    foreach ($occtype->result() as $ot)
								                    {               
								                        //echo $ot->education_name;
								                    
								                    ?>
								                    <option value="<?php echo $ot->occupation_table_id; ?>" <?php if($occ_type == $ot->occupation_table_id ) { echo "Selected";}?> style="padding: 3px;border-bottom: solid 1px silver;"><?php echo $ot->occupation_name; ?></option>
								                    <?php } ?>
								                  </select>
								                </div>
								                <label for="inputPassword3" class="col-sm-2 control-label">Occupation</label>
								                <div class="col-sm-3">
								                    <select class="form-control" name="occupation" id="occupation">
								                      <option value="" <?php echo  set_select('occupation', 'Select'); ?>>Select</option>
								                      <option value="Government" <?php if($occ == "Government") { echo "Selected"; }?>>Government</option>
								                      <option value="Private" <?php if($occ == "Private") { echo "Selected"; }?>>Private</option>
								                      <option value="Business" <?php if($occ == "Business") { echo "Selected"; }?>>Business</option>
								                      <option value="Defence" <?php if($occ == "Defence") { echo "Selected"; }?>>Defence</option>
								                      <option value="Self Employeed" <?php if($occ == "Self Employeed") { echo "Selected"; }?>>Self Employeed</option>
								                      <option value="Other" <?php if($occ == "Other") { echo "Selected"; }?>>Other</option>
								                    </select>
								                </div>
							                </div>

							                <div class="form-group">
								                <label for="inputEmail3" class="col-sm-2 control-label">Occupation Details</label>
								                <div class="col-sm-3">
								                  <input type="text" class="form-control" name="occdetails" id="occdetails" placeholder="Occupation Details" value="<?php echo $occupation_details; ?>">
								                </div>
								                <label for="inputPassword3" class="col-sm-2 control-label">Income</label>
								                <div class="col-sm-2">
								                  <select class="form-control" name="income" id="income">
								                    <option value="-1">Any</option>
								                    <option value="Less than Rs.50 thousand" <?php if($income == "Less than Rs.50 thousand") { echo "Selected"; }?>>Less than Rs.50 thousand</option>
								                    <option value="Rs.50 thousand" <?php if($income == "Rs.50 thousand") { echo "Selected"; }?>>Rs.50 thousand </option>
								                    <option value="Rs.1 Lakh" <?php if($income == "Rs.1 Lakh") { echo "Selected"; }?>>Rs.1 Lakh</option>
								                    <option value="Rs.2 Lakh" <?php if($income == "Rs.2 Lakh") { echo "Selected"; }?>>Rs.2 Lakh</option>
								                    <option value="Rs.3 Lakh" <?php if($income == "Rs.3 Lakh") { echo "Selected"; }?>>Rs.3 Lakh</option>
								                    <option value="Rs.4 Lakh" <?php if($income == "Rs.4 Lakh") { echo "Selected"; }?>>Rs.4 Lakh</option>
								                    <option value="Rs.5 Lakh" <?php if($income == "Rs.5 Lakh") { echo "Selected"; }?>>Rs.5 Lakh</option>
								                    <option value="Rs.6 Lakh" <?php if($income == "Rs.6 Lakh") { echo "Selected"; }?>>Rs.6 Lakh</option>
								                    <option value="Rs.7 Lakh" <?php if($income == "Rs.7 Lakh") { echo "Selected"; }?>>Rs.7 Lakh</option>
								                    <option value="Rs.8 Lakh" <?php if($income == "Rs.8 Lakh") { echo "Selected"; }?>>Rs.8 Lakh</option>
								                    <option value="Rs.9 Lakh" <?php if($income == "Rs.9 Lakh") { echo "Selected"; }?>>Rs.9 Lakh</option>
								                    <option value="Rs.10 Lakh" <?php if($income == "Rs.10 Lakh") { echo "Selected"; }?>>Rs.10 Lakh</option>
								                    <option value="Rs.12 Lakh" <?php if($income == "Rs.12 Lakh") { echo "Selected"; }?>>Rs.12 Lakh</option>
								                    <option value="Rs.14 Lakh" <?php if($income == "Rs.14 Lakh") { echo "Selected"; }?>>Rs.14 Lakh</option>
								                    <option value="Rs.16 Lakh" <?php if($income == "Rs.16 Lakh") { echo "Selected"; }?>>Rs.16 Lakh</option>
								                    <option value="Rs.18 Lakh" <?php if($income == "Rs.18 Lakh") { echo "Selected"; }?>>Rs.18 Lakh</option>
								                    <option value="Rs.20 Lakh" <?php if($income == "Rs.20 Lakh") { echo "Selected"; }?>>Rs.20 Lakh</option>
								                    <option value="Rs.25 Lakh" <?php if($income == "Rs.25 Lakh") { echo "Selected"; }?>>Rs.25 Lakh</option>
								                    <option value="Rs.30 Lakh" <?php if($income == "Rs.30 Lakh") { echo "Selected"; }?>>Rs.30 Lakh</option>
								                    <option value="Rs.35 Lakh" <?php if($income == "Rs.35 Lakh") { echo "Selected"; }?>>Rs.35 Lakh</option>
								                    <option value="Rs.40 Lakh" <?php if($income == "Rs.40 Lakh") { echo "Selected"; }?>>Rs.40 Lakh</option>
								                    <option value="Rs.45 Lakh" <?php if($income == "Rs.45 Lakh") { echo "Selected"; }?>>Rs.45 Lakh</option>
								                    <option value="Rs.50 Lakh" <?php if($income == "Rs.50 Lakh") { echo "Selected"; }?>>Rs.50 Lakh</option>
								                    <option value="Rs.60 Lakh" <?php if($income == "Rs.60 Lakh") { echo "Selected"; }?>>Rs.60 Lakh</option>
								                    <option value="Rs.70 Lakh" <?php if($income == "Rs.70 Lakh") { echo "Selected"; }?>>Rs.70 Lakh</option>
								                    <option value="Rs.80 Lakh" <?php if($income == "Rs.80 Lakh") { echo "Selected"; }?>>Rs.80 Lakh</option>
								                    <option value="Rs.90 Lakh" <?php if($income == "Rs.90 Lakh") { echo "Selected"; }?>>Rs.90 Lakh</option>
								                    <option value="Rs.1 Crore" <?php if($income == "Rs.1 Crore") { echo "Selected"; }?>>Rs.1 Crore</option>
								                    <option value="Rs.1 Crore & Above" <?php if($income == "Rs.1 Crore & Above") { echo "Selected"; }?>>Rs.1 Crore & Above</option>
								                  </select>
								                </div>
								                <div class="col-sm-2">
								                  <select class="form-control" name="income2" id="income2">
								                    <option  value="">Select</option>
								                    <option value="Monthly" <?php if($incometype == "Monthly") { echo "Selected"; }?>>Monthly</option>
								                    <option value="Annualy" <?php if($incometype == "Annualy") { echo "Selected"; }?>>Annualy</option>
								                  </select>
								                </div>
							                </div>

											
											<div class="form-group">
												<label for="inputEmail3" class="col-sm-2 control-label">Property</label>
								                <div class="col-sm-2">
								                  <select class="form-control" name="property" id="property" >
								                    <option value="-1" selected="selected">Any</option>
								                    <option value="Less than Rs.50 thousand" <?php if($property == "Less than Rs.50 thousand") { echo "Selected"; }?>>Less than Rs.50 thousand</option>
								                    <option value="Rs.50 thousand" <?php if($property == "Rs.1 Crore") { echo "Selected"; }?>>Rs.50 thousand </option>
								                    <option value="Rs.1" <?php if($property == "Rs.1") { echo "Selected"; }?>>Rs.1 Lakh</option>
								                    <option value="Rs.2" <?php if($property == "Rs.2") { echo "Selected"; }?>>Rs.2 Lakh</option>
								                    <option value="Rs.3" <?php if($property == "Rs.3") { echo "Selected"; }?>>Rs.3 Lakh</option>
								                    <option value="Rs.4" <?php if($property == "Rs.4") { echo "Selected"; }?>>Rs.4 Lakh</option>
								                    <option value="Rs.5" <?php if($property == "Rs.5") { echo "Selected"; }?>>Rs.5 Lakh</option>
								                    <option value="Rs.6" <?php if($property == "Rs.6") { echo "Selected"; }?>>Rs.6 Lakh</option>
								                    <option value="Rs.7" <?php if($property == "Rs.7") { echo "Selected"; }?>>Rs.7 Lakh</option>
								                    <option value="Rs.8" <?php if($property == "Rs.8") { echo "Selected"; }?>>Rs.8 Lakh</option>
								                    <option value="Rs.9" <?php if($property == "Rs.9") { echo "Selected"; }?>>Rs.9 Lakh</option>
								                    <option value="Rs.10" <?php if($property == "Rs.10") { echo "Selected"; }?>>Rs.10 Lakh</option>
								                    <option value="Rs.12" <?php if($property == "Rs.12") { echo "Selected"; }?>>Rs.12 Lakh</option>
								                    <option value="Rs.14" <?php if($property == "Rs.14") { echo "Selected"; }?>>Rs.14 Lakh</option>
								                    <option value="Rs.16" <?php if($property == "Rs.16") { echo "Selected"; }?>>Rs.16 Lakh</option>
								                    <option value="Rs.18" <?php if($property == "Rs.18") { echo "Selected"; }?>>Rs.18 Lakh</option>
								                    <option value="Rs.20" <?php if($property == "Rs.20") { echo "Selected"; }?>>Rs.20 Lakh</option>
								                    <option value="Rs.25" <?php if($property == "Rs.25") { echo "Selected"; }?>>Rs.25 Lakh</option>
								                    <option value="Rs.30" <?php if($property == "Rs.30") { echo "Selected"; }?>>Rs.30 Lakh</option>
								                    <option value="Rs.35" <?php if($property == "Rs.35") { echo "Selected"; }?>>Rs.35 Lakh</option>
								                    <option value="Rs.40" <?php if($property == "Rs.40") { echo "Selected"; }?>>Rs.40 Lakh</option>
								                    <option value="Rs.45" <?php if($property == "Rs.45") { echo "Selected"; }?>>Rs.45 Lakh</option>
								                    <option value="Rs.50" <?php if($property == "Rs.50") { echo "Selected"; }?>>Rs.50 Lakh</option>
								                    <option value="Rs.60" <?php if($property == "Rs.60") { echo "Selected"; }?>>Rs.60 Lakh</option>
								                    <option value="Rs.70" <?php if($property == "Rs.70") { echo "Selected"; }?>>Rs.70 Lakh</option>
								                    <option value="Rs.80" <?php if($property == "Rs.80") { echo "Selected"; }?>>Rs.80 Lakh</option>
								                    <option value="Rs.90" <?php if($property == "Rs.90") { echo "Selected"; }?>>Rs.90 Lakh</option>
								                    <option value="Rs.1" <?php if($property == "Rs.1") { echo "Selected"; }?>>Rs.1</option>
								                    <option value="Rs.2" <?php if($property == "Rs.2") { echo "Selected"; }?>>Rs.2 Crore</option>
								                    <option value="Rs.3" <?php if($property == "Rs.3") { echo "Selected"; }?>>Rs.3 Crore</option>
								                    <option value="Rs.4" <?php if($property == "Rs.4") { echo "Selected"; }?>>Rs.4 Crore</option>
								                    <option value="Rs.5" <?php if($property == "Rs.5") { echo "Selected"; }?>>Rs.5 Crore</option>
								                    <option value="Rs.6" <?php if($property == "Rs.6") { echo "Selected"; }?>>Rs.6 Crore</option>
								                    <option value="Rs.7" <?php if($property == "Rs.7") { echo "Selected"; }?>>Rs.7 Crore</option>
								                    <option value="Rs.8" <?php if($property == "Rs.8") { echo "Selected"; }?>>Rs.8 Crore</option>
								                    <option value="Rs.9" <?php if($property == "Rs.9") { echo "Selected"; }?>>Rs.9 Crore</option>
								                    <option value="Rs.10" <?php if($property == "Rs.10") { echo "Selected"; }?>>Rs.10 Crore</option>
								                    <option value="Rs.12" <?php if($property == "Rs.12") { echo "Selected"; }?>>Rs.12 Crore</option>
								                    <option value="Rs.14" <?php if($property == "Rs.14") { echo "Selected"; }?>>Rs.14 Crore</option>
								                    <option value="Rs.16" <?php if($property == "Rs.16") { echo "Selected"; }?>>Rs.16 Crore</option>
								                    <option value="Rs.18" <?php if($property == "Rs.18") { echo "Selected"; }?>>Rs.18 Crore</option>
								                    <option value="Rs.20" <?php if($property == "Rs.20") { echo "Selected"; }?>>Rs.20 Crore</option>
								                    <option value="Rs.25" <?php if($property == "Rs.25") { echo "Selected"; }?>>Rs.25 Crore</option>
								                    <option value="Rs.30" <?php if($property == "Rs.30") { echo "Selected"; }?>>Rs.30 Crore</option>
								                    <option value="Rs.35" <?php if($property == "Rs.35") { echo "Selected"; }?>>Rs.35 Crore</option>
								                    <option value="Rs.40" <?php if($property == "Rs.40") { echo "Selected"; }?>>Rs.40 Crore</option>
								                    <option value="Rs.45" <?php if($property == "Rs.45") { echo "Selected"; }?>>Rs.45 Crore</option>
								                    <option value="Rs.50" <?php if($property == "Rs.50") { echo "Selected"; }?>>Rs.50 Crore</option>
								                    <option value="Rs.60" <?php if($property == "Rs.60") { echo "Selected"; }?>>Rs.60 Crore</option>
								                    <option value="Rs.70" <?php if($property == "Rs.70") { echo "Selected"; }?>>Rs.70 Crore</option>
								                    <option value="Rs.80" <?php if($property == "Rs.80") { echo "Selected"; }?>>Rs.80 Crore</option>
								                    <option value="Rs.90" <?php if($property == "Rs.90") { echo "Selected"; }?>>Rs.90 Crore</option>
								                    <option value="Rs.100" <?php if($property == "Rs.100") { echo "Selected"; }?>>Rs.100 Crore</option> 
								                    <option value="Rs.100 Crore & Above" <?php if($property == "Rs.100 Crore & Above") { echo "Selected"; }?>>Rs.100 Crore & Above</option>
								                  </select>
								                </div>
								                <div class="col-sm-2">
								                  <select class="form-control" name="property2" id="property2">
								                    <option  value="">Select</option>
								                    <option value="Lakhs" <?php if($property_price_type == "Lakhs") { echo "Selected"; }?>>Lakhs</option>
								                    <option value="Crores" <?php if($property_price_type == "Crores") { echo "Selected"; }?>>Crores</option>
								                  </select>
								                </div> 
											</div>

											<h3>Family Details</h3>
											<hr>

											<div class="form-group">
								                <label for="inputEmail3" class="col-sm-2 control-label">Father Name</label>
								                <div class="col-sm-3">
								                  <input type="text" class="form-control" name="fathername" id="fathername" placeholder="Father Name" value="<?php echo $fathername; ?>">
								                </div>
								                <label for="inputPassword3" class="col-sm-2 control-label">Father Occupation</label>
								                <div class="col-sm-3">
								                  <input type="text" class="form-control" name="fdetails" id="fdetails" placeholder="Father details" value="<?php echo $fatheroccupation; ?>">
								                </div>
							                </div>

							                <div class="form-group">
								                <label for="inputEmail3" class="col-sm-2 control-label">Mother Name</label>
								                <div class="col-sm-3">
								                  <input type="text" class="form-control" name="mothername" id="mothername" placeholder="Mother Name" value="<?php echo $mothername; ?>">
								                </div>
								                <label for="inputPassword3" class="col-sm-2 control-label">Mother Occupation</label>
								                <div class="col-sm-3">
								                  <input type="text" class="form-control" name="mdetails" id="mdetails" placeholder="Mother details" value="<?php echo $motheroccupation; ?>">
								                </div>
							                </div>

											<div class="form-group">
								                <label for="inputEmail3" class="col-sm-2 control-label">No. Of Brothers</label>
								                <div class="col-sm-3">
								                    <select class="form-control" name="nob" id="nob">
							                          <option value="0" <?php echo  set_select('nob', '0'); ?>>Select</option>
							                          <option value="none" <?php if($bro == "none") { echo "Selected"; }?>>none</option>
							                          <option value="1" <?php if($bro == "1") { echo "Selected"; }?>>1</option>
							                          <option value="2" <?php if($bro == "2") { echo "Selected"; }?>>2</option>
							                          <option value="3" <?php if($bro == "3") { echo "Selected"; }?>>3</option>
							                          <option value="4" <?php if($bro == "4") { echo "Selected"; }?>>4</option>
							                          <option value="5+" <?php if($bro == "5+") { echo "Selected"; }?>>5+</option>
							                        </select>
								                </div>
								                <label for="inputPassword3" class="col-sm-2 control-label">No. Of Brothers Married</label>
								                <div class="col-sm-3">
								                  <select class="form-control" name="brosm" id="brosm">
						                            <option value="0" <?php echo  set_select('brosm', '0'); ?>>Select</option>
						                            <option value="none" <?php if($mbro == "none") { echo "Selected"; }?>>none</option>
						                            <option value="1" <?php if($mbro == "1") { echo "Selected"; }?>>1</option>
						                            <option value="2" <?php if($mbro == "2") { echo "Selected"; }?>>2</option>
						                            <option value="3" <?php if($mbro == "3") { echo "Selected"; }?>>3</option>
						                            <option value="4" <?php if($mbro == "4") { echo "Selected"; }?>>4</option>
						                            <option value="5+" <?php if($mbro == "5+") { echo "Selected"; }?>>5+</option>
						                           </select>
								                </div>
							                </div>

							                <div class="form-group">
								                <label for="inputEmail3" class="col-sm-2 control-label">No. Of Sisters</label>
								                <div class="col-sm-3">
								                    <select class="form-control" name="nos" id="nos">
							                          <option value="0" <?php echo  set_select('nos', '0'); ?>>Select</option>
							                          <option value="none" <?php if($sis == "none") { echo "Selected"; }?>>none</option>
							                          <option value="1" <?php if($sis == "1") { echo "Selected"; }?>>1</option>
							                          <option value="2" <?php if($sis == "2") { echo "Selected"; }?>>2</option>
							                          <option value="3" <?php if($sis == "3") { echo "Selected"; }?>>3</option>
							                          <option value="4" <?php if($sis == "4") { echo "Selected"; }?>>4</option>
							                          <option value="5+" <?php if($sis == "5+") { echo "Selected"; }?>>5+</option>
							                        </select>
								                </div>
								                <label for="inputPassword3" class="col-sm-2 control-label">No of Sisters married</label>
								                <div class="col-sm-3">
								                    <select class="form-control" name="sism" id="sism">
							                            <option value="0" <?php echo  set_select('sism', '0'); ?>>Select</option>
							                            <option value="none" <?php if($msis == "none") { echo "Selected"; }?>>none</option>
							                            <option value="1" <?php if($msis == "1") { echo "Selected"; }?>>1</option>
							                            <option value="2" <?php if($msis == "2") { echo "Selected"; }?>>2</option>
							                            <option value="3" <?php if($msis == "3") { echo "Selected"; }?>>3</option>
							                            <option value="4" <?php if($msis == "4") { echo "Selected"; }?>>4</option>
							                            <option value="5+" <?php if($msis == "5+") { echo "Selected"; }?>>5+</option>
							                        </select>
								                </div>
							                </div>

											<div class="form-group">
												<label for="inputEmail3" class="col-sm-2 control-label">Address</label>
								                <div class="col-sm-5">
								                  <textarea name="address" class="form-control" id="inputDefault" rows="6" ><?php echo $address; ?></textarea>
								                </div>
												
											</div>

                                            <h3>Uploaded Photos</h3>
											<hr>
                                            <div>
                                            	<hr>
                                            	<?php 
											      foreach ($sql->result() as $k) {
											       ?>
											       <img src="<?php echo base_url(); ?>assets/uploads/<?php echo $k->imgpath; ?>" width="100px" height="100px">
											    <?php } ?>
                                            </div>

                                            <h3>Photo Upload</h3>
											<hr>
                                            <div class="form-group">
								                <label for="inputPassword3" class="col-sm-2 control-label">Image Upload</label>
								                <div class="col-sm-3">
								                  <!--<input type="file" id="picone" name="userfile[]">-->
								                  <?php echo form_error('uploadedimages[]'); ?>
								                  <?php echo form_upload('uploadedimages[]','','multiple'); ?>
								                </div>
							                </div>


											
											<div class="form-group">
												<label class="col-md-3 control-label"></label>
												<div class="col-md-6 col-xs-11">
													<button type="submit"  class="btn btn-primary hidden-xs">Submit</button>
												</div>
											</div>											
										</form>
									</div>
								</section>
							</div>
						</div>


	<script type="text/javascript">

	    //Height Script// 

	      function roundit(which){
	        return Math.round(which*100)/100
	      }
	      
	      function roundit(which){
	        return Math.round(which*100)/100
	      }

	      function convercms(phval)
	      {
	      ///var cms= (phval/0.032808).toFixed(2);;

	      ///var cms= phval*30.48;

	      with (document.register_form){
	      cms=roundit(height.value*30.48);
	      document.getElementById('hgtcms').innerHTML =cms+" cms";

	      }
	      }

	      function convert_CMtoFT(cms)
	      {
	        var inch_val = Math.round(cms * 0.393701);
	        ///alert(inch_val);
	        var tot_inches = inch_val/12;
	        
	        var ft = Math.floor(tot_inches);
	        var inch_val = inch_val%12;
	        /*var str_tot_inch = tot_inches.toString();
	        var arr = str_tot_inch.split('.');
	        var ft = arr[0];
	        var inch = arr[1];
	        
	        var inch_dec = inch.substring(0,1);
	        var inches = new Number(inch_dec);
	        var inch_val = inches+1;*/
	        
	        
	        if(inch_val<10)
	        {
	          var ft_inch = ft+'.0'+inch_val;
	        }
	        
	        else 
	        {
	          var ft_inch = ft+'.'+inch_val;
	        }
	        ///var inch = Math.round(arr[1]);
	        
	         var heightlistbox = document.getElementById("height");
	       
	        for(var x=0;x < heightlistbox.length  ; x++)
	        {
	           
	           if(heightlistbox.options[x].value == ft_inch)
	           {
	        
	            heightlistbox.options[x].selected = true;
	            return ;
	           }
	        }
	      }

	      function convert_FTtoCM(ip)
	      {
	        var arr = ip.split('.');
	        var ft = arr[0];
	        var inch = arr[1];
	        var f_dig = inch.substring(0,1);
	        if(f_dig==0)
	        {
	          inch = inch.substring(1);
	        }
	        var inches = new Number(inch);
	        var tot_inch = (12*ft )+ inches;
	        ///alert(ft+'--'+inch+'--'+tot_inch);
	        var cms = tot_inch * 2.54;
	        cms = Math.round(cms);
	        
	        ///alert(cms);
	        
	         var cmslistbox = document.getElementById("CMS")
	       
	        for(var x=0;x < cmslistbox.length  ; x++)
	        {
	           
	           if(cmslistbox.options[x].value == cms)
	           {
	        
	            cmslistbox.options[x].selected = true;
	            return ;
	           }
	        }
	      }
	      
	      
	    //Ends Height Script// 


	    // States Select Option Starts//

	    function ajaxFunction(){
	        var country = document.getElementById("country").value;
	        //alert(country);
	     
	      	$.ajax({
		      type: "POST",
		      url: '<?php echo site_url("admin/ajaxcountry")?>',
		      data: {country:country},
		      success: function(res) {
		      //alert(res); 
		      $('#states').html(res);
		      }
		     });  
	    }

	    function ajaxC(id){
	        var uid = id;
	        var country = document.getElementById("country").value;
	        //alert(country);
	     
	     
	      	$.ajax({
		      type: "POST",
		      url: '<?php echo site_url("admin/ajaxcountry")?>',
		      data: {country:country,uid:uid},
		      success: function(res) {
		      //alert(res); 
		      $('#states').html(res);
		      }
		     });  
	    }

	    // States Select Option Ends//

	    // districts Select Option Starts//


	    function ajaxState(){
	    	
	        var state = document.getElementById("states").value;
	        //alert(state);
	        $.ajax({
	      type: "POST",
	      url: '<?php echo site_url("admin/ajaxstates")?>',
	      data: {state:state},
	      success: function(res) {
	      //alert(res); 
	      $('#districts').html(res);
	      }
	      });  
	    }


	    function ajaxS(id){
	    	var uid = id;
	        var state = document.getElementById("states").value;
	        //alert(state);
	        $.ajax({
	      type: "POST",
	      url: '<?php echo site_url("admin/ajaxstates")?>',
	      data: {state:state,uid:uid},
	      success: function(res) {
	      //alert(res); 
	      $('#districts').html(res);
	      }
	      });  
	    }

	    // district Select Option Ends//

	    // mandal select option starts //

	    function ajaxMandals()
	    {
	        var district = document.getElementById("districts").value;
	        //alert(district);
	        $.ajax({
		      type: "POST",
		      url: '<?php echo site_url("admin/ajaxmandals")?>',
		      data: {district:district},
		      success: function(res) {
		      //alert(res); 
		      $('#mandals').html(res);
		      }
		    });  
	    }

	    function ajaxM(id)
	    {
	    	var uid = id;
	        var district = document.getElementById("districts").value;
	        //alert(district);
	        $.ajax({
		      type: "POST",
		      url: '<?php echo site_url("admin/ajaxmandals")?>',
		      data: {district:district,uid:uid},
		      success: function(res) {
		      //alert(res); 
		      $('#mandals').html(res);
		      }
		    });  
	    }

	    // mandal select option ends //

	    // birthstar select option starts //
        
         function getAjaxRaasi(birthstar)
	      {
	        //alert(birthstar);
	        $.get("ajax_get_raasi1",{ birth_star_id:birthstar },function(response){
	        var raasi=response.trim();
	        var raasilistbox=document.getElementById("raasi");
	        for(var x=0;x < raasilistbox.length; x++)
	        {  
	          if(raasilistbox.options[x].value==raasi)
	          {
	            raasilistbox.options[x].selected = true;
	            return ;
	          }
	        }
	        });
	      }



	    // birthstar select option ends //

	    // education select option starts //

	    function ajaxEducation()
	    {
	      var edtype = document.getElementById("edtype").value;
	      
	      //alert(edtype);
	      $.ajax({
	      type: "POST",
	      url: '<?php echo site_url("admin/ajaxeducation")?>',
	      data: {
	             edtype:edtype
	             
	            },
	      success: function(res) {
	      //alert(res); 
	      $('#education').html(res);
	      }
	      }); 
	    }

	    function ajaxE(id)
	    {
	      var uid = id;
	      var edtype = document.getElementById("edtype").value;
	      
	      //alert(edtype);
	      $.ajax({
	      type: "POST",
	      url: '<?php echo site_url("admin/ajaxeducation")?>',
	      data: {
	             edtype:edtype,
	             uid:uid
	            },
	      success: function(res) {
	      //alert(res); 
	      $('#education').html(res);
	      }
	      }); 
	    }

	    // education select option ends //

	    // hiding fields //

	    function hideFields()
	    {
	    	var religion=$("#religion").val();
	    	//alert(religion);
	    	if(religion=='Christian' || religion=='Muslim - Shia' || religion=='Muslim - Sunni' || religion=='Muslim - Others')
	    	{
                 $('#hgothram').hide();
                 $('#hbstar').hide();
                 $('#hpadam').hide();
	    	}else{
	    		$('#hgothram').show();
                $('#hbstar').show();
                $('#hpadam').show();
	    	}
	    }

	    // hiding fields //

	    // check email id is available starts //

	    function check_email()
	    {
	        var lemail=$("#email").val();
	        //alert(lemail);
	        $.ajax({
	        type: "POST",
	        url: '<?php echo site_url("admin/checkemail")?>',
	        data: {lemail:lemail},
	        success: function(res) {
	        //alert(res); 
	        $('#email').html(res);
	        }
	        });  

	        
	    }

	    // check email id is available ends // 




	</script>
						
								
<?php
 include 'footer.php'; 

 ?>

 <script type="text/javascript">

    $(document).ready(function(){
		// we call the function
		 var url = window.location.href;
		 var res = url.split("?id="); 
         var id = res[1];
         //alert(id);
        
		ajaxC(id);
        setTimeout(function(){
		  ajaxS(id);
		  setTimeout(function(){
		    ajaxM(id);
		    setTimeout(function(){
			   ajaxE(id);
			}, 2500);
		  }, 2500);
		}, 2500);
       
		


		 

    });

 </script>