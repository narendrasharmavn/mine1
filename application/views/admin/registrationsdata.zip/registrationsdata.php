<?php 
include 'header.php';
?>
  <!-- Specific Page Vendor CSS -->
		<link rel="stylesheet" href="assets/vendor/select2/select2.css" />
		<link rel="stylesheet" href="assets/vendor/jquery-datatables-bs3/assets/css/datatables.css" />
		<!-- Web Fonts  -->
		<link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">

			

				<section role="main" class="content-body">
					<header class="page-header">
						<h2>Member Registrations Report</h2>
					
						<div class="right-wrapper pull-right">
							<ol class="breadcrumbs">
								<li>
									<a href="index.html">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>Tables</span></li>
								<li><span>Advanced</span></li>
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>

					
						
						<section class="panel">
							<header class="panel-heading">
								<div class="panel-actions">
									<a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
									<a href="#" class="panel-action panel-action-dismiss" data-panel-dismiss></a>
								</div>
						
								<h2 class="panel-title">Member Registrations Report</h2>
							</header>
							<div class="panel-body">
								
								<table class="table table-bordered table-striped mb-none" id="datatable-tabletools" data-swf-path="assets/vendor/jquery-datatables/extras/TableTools/swf/copy_csv_xls_pdf.swf">
									<thead>
										<tr>
											<th>Name</th>
											<th>Surname</th>
											<th>Gender</th>
											<th>Date Of Birth</th>
											<th>Age</th>
											<th class="hidden-phone">Edit</th>
											<th class="hidden-phone">Delete</th>
											<th class="hidden-phone">print</th>
										</tr>
									</thead>
									<tbody>
										<?php 
										
											$query = $this->db->query("SELECT * from register WHERE user_status='Active' ORDER BY ID DESC");

											foreach ($query->result() as $k) {
												# code...
											
											
										?>
										<tr>
											<td><?php echo $k->name; ?></td>
											<td><?php echo $k->lastname; ?></td>
											<td><?php echo $k->gender; ?></td>
											<td><?php echo $k->dob; ?></td>
											<td><?php echo $k->age; ?></td>
											
											
											<td class="center hidden-phone">
												<a href="editmembersdetails?id=<?php echo $k->ID; ?>" target="_blank"  name="edit" id="edit" value="edit">
													Edit
												</a>
											</td>
											<td class="center hidden-phone"><a href="#" onclick="deletemember(<?php echo $k->ID; ?>)">Delete</a></td>

											<td class="center hidden-phone">
												

												<a href="printdata?id=<?php echo $k->ID; ?>" target="_blank"  name="print" id="print" value="print">
							                        Print
							                    </a>
							                </td>
										</tr>
										<?php } ?>
									</tbody>
								</table>
							</div>
						</section>
						
<script type="text/javascript">
   function deletemember(id)
   {
   	    var uid = id;
   	    //alert(uid);
   	    if (confirm("Are You Sure You Want To Delete") == true) {
	        
            $.ajax({
		      type: "POST",
		      url: '<?php echo site_url("admin/deletemember")?>',
		      data: {
		             
		             uid:uid
		            },
		      success: function(res) {
		      //alert(res); 
		      location.reload();
		      }
	        }); 

	    } else {
	        location.reload();
	    }
   }
</script>			

<?php
     include 'footer.php'; 
?>