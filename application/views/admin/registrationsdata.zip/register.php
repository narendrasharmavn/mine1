<?php
 include 'header.php'; 

 ?>

				<section role="main" class="content-body">
					<header class="page-header">
						<h2>Member Registration</h2>
					
						<div class="right-wrapper pull-right">
							<ol class="breadcrumbs">
								<li>
									<a href="index.html">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>Member Registration</span></li>
								<li><span>Registration</span></li>
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>

					<!-- start: page -->
						<div class="row">
							<div class="col-lg-12">
								<section class="panel">
									<header class="panel-heading">
										<div class="panel-actions">
											<a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a>
											<a href="#" class="panel-action panel-action-dismiss" data-panel-dismiss></a>
										</div>
						
										<h2 class="panel-title">Registration</h2>
									</header>
									<div class="panel-body">
										
										<?php 
								            echo form_open_multipart('Admin/submitregister',array('class' => 'form-horizontal'));
								        ?>

								         <?php echo $this->session->flashdata('success'); ?> 
											<div class="form-group">
								                <label for="inputEmail3" class="col-sm-2 control-label">Name</label>
								                <div class="col-sm-3">
								                  <input type="text" class="form-control" name="fname" id="fname" placeholder="Name" value="<?php echo set_value('fname'); ?>">
								                </div>
								                <label for="inputPassword3" class="col-sm-2 control-label">Surname</label>
								                <div class="col-sm-3">
								                  <input type="text" class="form-control" name="lname" id="lname" placeholder="Surname" value="<?php echo set_value('surname'); ?>">
								                </div>
							                </div>

							                <div class="form-group">
								                <label for="inputEmail3" class="col-sm-2 control-label">Email</label>
								                <div class="col-sm-3">
								                  <input type="text" class="form-control" name="email" id="email" placeholder="Email" value="<?php echo set_value('email'); ?>" onkeyup='check_email()' onpaste='check_email()'>
								                  <div id="email"></div>
								                  <span class="text-danger"><?php echo form_error('email'); ?></span>
								                </div>
								                <label for="inputPassword3" class="col-sm-2 control-label">Gender</label>
								                <div class="col-md-1 col-sm-2">
								                  <label class="radio-inline">
								                    <input type="radio" name="gender" id="male" value="Male" <?php echo  set_radio('gender', 'Male'); ?>> Male
								                  </label>
										        </div>
								                <div class="col-md-1 col-sm-2">
								                  <label class="radio-inline">
								                    <input type="radio" name="gender" id="female" value="Female" <?php echo  set_radio('gender', 'Female'); ?>> Female
								                  </label>
								                </div> 
							                </div>

							                <div class="form-group">
								                <label for="inputEmail3" class="col-sm-2 control-label">Birthplace</label>
								                <div class="col-sm-3">
								                  <input type="text" class="form-control" name="birthplace" id="birthplace" placeholder="Birthplace" value="<?php echo set_value('birthplace'); ?>">
								                </div>
								                <label for="inputPassword3" class="col-sm-2 control-label">Date & Time Of Birth</label>
								                <div class="col-sm-3">
								                  <input type="text" id="demo1" name="dob" class="form-control" maxlength="25" size="25"/>
								                    <img src="<?php echo base_url();  ?>assets/img/calendarimages/cal.gif" onclick="javascript:NewCssCal ('demo1','MMddyyyy','dropdown',true,'12',true)"
								                    style="float: right;margin-top: -24px;margin-right: 10px;"/>
								                </div>
							                </div>
											
											<div class="form-group">
												<label class="col-md-3 control-label" for="inputDefault">Height</label>
												<div class="col-md-2">
													<select class="form-control" size="4" name="height" id="height" onclick="centerSelectedOption(this.value)" onChange="convert_FTtoCM(this.value)">
									                    <option value="0" <?php echo  set_select('height', '0'); ?>>-Select-</option>
									                    <?php
									                    $arr = array(4,5,6);
									                    foreach($arr as $ft){
									                      for($inch=0;$inch<=11;$inch++){
									                        if($inch<10){
									                          $inch_val = '0'.$inch;
									                        }else{
									                          $inch_val = $inch;
									                        }
									                          $ht_val = $ft.'.'.$inch_val;

									                          $ht_disp = $ft.'\' '.$inch.'&quot;';
									                        if($ht_val==strip_tags($this->input->post('height'))){
									                            echo '<option value="'.$ht_val.'" selected="selected">'.$ht_disp.'</option>';
									                        }else{
									                          echo '<option value="'.$ht_val.'">'.$ht_disp.'</option>';
									                        }
									                        }
									                    }
									                    ?>
									                </select>
												</div>
												<div class="col-sm-1"><b>OR</b></div>
									                <div class="col-sm-2">
									                 <select class="form-control" name="CMS" id="CMS" onChange="convert_CMtoFT(this.value)">
									                    <option value="0" <?php echo  set_select('CMS', '0'); ?>>-Cms-</option>
									                    <?php
									                    $CMS=$this->input->post('CMS');
									                    for($i=100;$i<=213;$i++)
									                    {
									                      if($CMS==$i){
									                        $checked="selected";
									                      }else{
									                        $checked="";
									                      }
									                      echo '<option value="'.$i.'"'. $checked.'>'.$i.'cm</option>';
									                    }
									                  ?>
									                  </select>
									            </div>
											</div>

											<div class="form-group">
								                <label for="inputEmail3" class="col-sm-2 control-label">Country</label>
								                <div class="col-sm-3">
								                    <select class="form-control" name="country" id="country"  onchange="ajaxFunction(),showValue(this.value),showState()">
									                    <option>Select</option>
									                    <?php 
									                    foreach ($countries->result() as $row)
									                    {               
									                        //echo $row->name;
									                    
									                    ?>
									                    <option value="<?php echo $row->name; ?>"><?php echo $row->name; ?></option>
									                    <?php } ?>
								                    </select>
								                </div>
								                <label for="inputPassword3" class="col-sm-2 control-label">State</label>
								                <div class="col-sm-3">
								                    <select class="form-control" name="states" id="states" onchange="ajaxState()">
									                    <option>Select</option>
									                </select>
								                </div>
							                </div>

							                <div class="form-group">
							                	<label for="inputEmail3" class="col-sm-2 control-label">Districts</label>
								                <div class="col-sm-3">
								                    <select class="form-control" name="districts" id="districts" onchange="ajaxMandals()">
									                    <option>Select</option>
									                </select>
								                </div>
								                <label for="inputEmail3" class="col-sm-2 control-label">Mandals</label>
								                <div class="col-sm-3">
								                    <select class="form-control" name="mandals" id="mandals" >
									                    <option>Select</option>
									                </select>
								                </div>
							                </div>

							                <div class="form-group">
								                <label for="inputPassword3" class="col-sm-2 control-label">Villages</label>
								                <div class="col-sm-3">
								                    <input type="text" class="form-control" name="village" id="village" placeholder="Village" value="<?php echo set_value('village'); ?>">
								                </div>
								                <label for="inputPassword3" class="col-sm-2 control-label">Mobile Number</label>
								                <div class="col-sm-3">
								                  <input type="number" class="form-control" name="mobile" id="mobile" placeholder="Mobile" value="<?php echo set_value('mobile'); ?>">
								                  
								                </div>
							                </div>

							                <div class="form-group">
								                <label for="inputEmail3" class="col-sm-2 control-label">Alternate Contact Number</label>
								                <div class="col-sm-3">
								                  <input type="number" class="form-control" name="anumber" id="anumber" placeholder="Alternate Number" value="<?php echo set_value('anumber'); ?>">
								                </div>
								                <label for="inputPassword3" class="col-sm-2 control-label">Marital Status</label>
								                <div class="col-sm-3">
								                    <select class="form-control" name="mstatus" id="mstatus">
								                      <option value="" <?php echo  set_select('mstatus', 'Select'); ?>>Select</option>
								                      <option value="UnMarried" <?php echo  set_select('mstatus', 'UnMarried'); ?>>UnMarried</option>
								                      <option value="Widow/Widower" <?php echo  set_select('mstatus', 'Widow/Widower'); ?>>Widow/Widower</option>
								                      <option value="Divorce" <?php echo  set_select('mstatus', 'Divorce'); ?>>Divorce</option>
								                      <option value="Separated" <?php echo  set_select('mstatus', 'Separated'); ?>>Separated</option>
								                    </select>
								                </div>
							                </div>

							                <div class="form-group">
								                <label for="inputEmail3" class="col-sm-2 control-label">Religion</label>
								                <div class="col-sm-3">
								                    <select class="form-control" name="religion" id="religion" onchange="hideFields()">
									                    <option>Select</option>
									                    <?php 
									                    foreach ($religion->result() as $row)
									                    {               
									                        //echo $row->religion_name;
									                    
									                    ?>
									                    <option value="<?php echo $row->religion_name; ?>"><?php echo $row->religion_name; ?></option>
									                    <?php } ?>
								                    </select>
								                </div>
								                <label for="inputPassword3" class="col-sm-2 control-label">Caste</label>
								                <div class="col-sm-3">
								                    <select class="form-control" name="caste" id="caste">
								                      <option value="0" <?php echo  set_select('caste', '0'); ?>>Select</option>
								                      <option value="OC" <?php echo  set_select('caste', 'OC'); ?>>OC </option>
								                      <option value="BC" <?php echo  set_select('caste', 'BC'); ?>>BC </option>
								                      <option value="SC" <?php echo  set_select('caste', 'SC'); ?>>SC </option>
								                      <option value="ST" <?php echo  set_select('caste', 'ST'); ?>>ST </option>
								                    </select>
								                  
								                </div>
							                </div>

							                <div class="form-group">
								                <label for="inputEmail3" class="col-sm-2 control-label">SubCaste</label>
								                <div class="col-sm-3">
								                  <input type="text" class="form-control" name="scaste" id="scaste" placeholder="SubCaste" value="<?php echo set_value('scaste'); ?>">
								                </div>
								                <div id="hgothram">
									                <label for="inputPassword3" class="col-sm-2 control-label">Gothram</label>
									                <div class="col-sm-3">
									                  <input type="text" class="form-control" name="gothram" id="gothram" placeholder="Gothram" value="<?php echo set_value('gothram'); ?>">
									                </div>
								                </div>
							                </div>

							                <div class="form-group" id="hbstar">
								                <label for="inputEmail3" class="col-sm-2 control-label">Birthstar</label>
								                <div class="col-sm-3">
								                    <select class="form-control" name="bstar" id="bstar" onChange="getAjaxRaasi(this.value)">
								                      <option>Select</option>
								                      <?php 
								                       foreach ($birthstar->result() as $bs)
								                      {               
								                          //echo $bs->name;
								                      ?>
								                      <option value="<?php echo $bs->s_birth_star; ?>"><?php echo $bs->s_birth_star; ?></option>
								                      <?php } ?>
								                    </select>
								                </div>
								                <label for="inputPassword3" class="col-sm-2 control-label">Raasi</label>
								                <div class="col-sm-3" >
								                    <select class="form-control" name="raasi" id="raasi">
								                      <option>Select</option>
								                      <?php 
								                       foreach ($raasi->result() as $rs)
								                      {               
								                          //echo $rs->s_raasi;
								                      ?>
								                      <option value="<?php echo $rs->s_raasi; ?>"><?php echo $rs->s_raasi; ?></option>
								                      <?php } ?>
								                    </select>
								                </div>
							                </div>

                                            <div class="form-group" id="hpadam">
								                <label for="inputEmail3" class="col-sm-2 control-label">Padam</label>
								                <div class="col-sm-3">
								                    <select class="form-control" name="padam" id="padam">
								                      <option value="0" <?php echo  set_select('padam', '0'); ?>>Select</option>
								                      <option value="N.A." <?php echo  set_select('padam', 'N.A.'); ?>>N.A. </option>
								                      <option value="First" <?php echo  set_select('padam', 'First'); ?>>First </option>
								                      <option value="Second" <?php echo  set_select('padam', 'Second'); ?>>Second </option>
								                      <option value="Third" <?php echo  set_select('padam', 'Third'); ?>>Third </option>
								                      <option value="Fourth" <?php echo  set_select('padam', 'Fourth'); ?>>Fourth </option>
								                    </select>
								                </div>
								                
							                </div>  
											
											
											
											<h3>Education & Occupation Details</h3>
											<hr>


											<div class="form-group">
								                <label for="inputEmail3" class="col-sm-2 control-label">Education Type</label>
								                <div class="col-sm-3">
								                  <select class="form-control" name="edtype" id="edtype" onchange="ajaxEducation(this.value)">
								                    <option value="0" <?php echo  set_select('edtype', '0'); ?> style="padding: 3px;border-bottom: solid 1px silver;">Select Education Type</option>
								                    <option style="padding: 3px;border-bottom: solid 1px silver;" value="any" <?php echo  set_select('edtype', 'any'); ?>>Any</option>
								                    <?php 
								                    foreach ($edtype->result() as $et)
								                    {               
								                      //echo $et->education_name;
								                    ?>
								                    <option value="<?php echo $et->education_table_id; ?>" style="padding: 3px;border-bottom: solid 1px silver;" ><?php echo $et->education_name; ?></option>
								                    <?php } ?>
								                  </select>
								                </div>
								                <label for="inputPassword3" class="col-sm-2 control-label">Education</label>
								                <div class="col-sm-3">
								                    <select class="form-control education"  id="education" name="education">
									                  <option style="padding: 3px;border-bottom: solid 1px silver;">Select Education</option>
									                  <option style="padding: 3px;border-bottom: solid 1px silver;" value="any" <?php echo  set_select('education', 'any'); ?>>Any</option>
									                </select>
								                </div>
							                </div>

											<div class="form-group">
								                <label for="inputEmail3" class="col-sm-2 control-label">Occupation Type</label>
								                <div class="col-sm-3">
								                  <select class="form-control"  name="occptype" id="occptype">
								                    <option value="0" <?php echo  set_select('occptype', '0'); ?> style="padding: 3px;border-bottom: solid 1px silver;">Select Occupation</option>
								                    <option style="padding: 3px;border-bottom: solid 1px silver;" value="any" <?php echo  set_select('occptype', 'any'); ?>>Any</option>
								                    <?php 
								                    foreach ($occtype->result() as $ot)
								                    {               
								                        //echo $ot->education_name;
								                    
								                    ?>
								                    <option value="<?php echo $ot->occupation_name; ?>" style="padding: 3px;border-bottom: solid 1px silver;"><?php echo $ot->occupation_name; ?></option>
								                    <?php } ?>
								                  </select>
								                </div>
								                <label for="inputPassword3" class="col-sm-2 control-label">Occupation</label>
								                <div class="col-sm-3">
								                    <select class="form-control" name="occupation" id="occupation">
								                      <option value="" <?php echo  set_select('occupation', 'Select'); ?>>Select</option>
								                      <option value="Government" <?php echo  set_select('occupation', 'Government'); ?>>Government</option>
								                      <option value="Private" <?php echo  set_select('occupation', 'Private'); ?>>Private</option>
								                      <option value="Business" <?php echo  set_select('occupation', 'Business'); ?>>Business</option>
								                      <option value="Defence" <?php echo  set_select('occupation', 'Defence'); ?>>Defence</option>
								                      <option value="Self Employeed" <?php echo  set_select('occupation', 'Self Employeed'); ?>>Self Employeed</option>
								                      <option value="Other" <?php echo  set_select('occupation', 'Other'); ?>>Other</option>
								                    </select>
								                </div>
							                </div>

							                <div class="form-group">
								                <label for="inputEmail3" class="col-sm-2 control-label">Occupation Details</label>
								                <div class="col-sm-3">
								                  <input type="text" class="form-control" name="occdetails" id="occdetails" placeholder="Occupation Details" value="<?php echo set_value('occdetails'); ?>">
								                </div>
								                <label for="inputPassword3" class="col-sm-2 control-label">Income</label>
								                <div class="col-sm-2">
								                  <select class="form-control" name="income" id="income">
								                    <option value="-1">Any</option>
								                    <option value="Less than Rs.50 thousand">Less than Rs.50 thousand</option>
								                    <option value="Rs.50 thousand">Rs.50 thousand </option>
								                    <option value="Rs.1 Lakh">Rs.1 Lakh</option>
								                    <option value="Rs.2 Lakh">Rs.2 Lakh</option>
								                    <option value="Rs.3 Lakh">Rs.3 Lakh</option>
								                    <option value="Rs.4 Lakh">Rs.4 Lakh</option>
								                    <option value="Rs.5 Lakh">Rs.5 Lakh</option>
								                    <option value="Rs.6 Lakh">Rs.6 Lakh</option>
								                    <option value="Rs.7 Lakh">Rs.7 Lakh</option>
								                    <option value="Rs.8 Lakh">Rs.8 Lakh</option>
								                    <option value="Rs.9 Lakh">Rs.9 Lakh</option>
								                    <option value="Rs.10 Lakh">Rs.10 Lakh</option>
								                    <option value="Rs.12 Lakh">Rs.12 Lakh</option>
								                    <option value="Rs.14 Lakh">Rs.14 Lakh</option>
								                    <option value="Rs.16 Lakh">Rs.16 Lakh</option>
								                    <option value="Rs.18 Lakh">Rs.18 Lakh</option>
								                    <option value="Rs.20 Lakh">Rs.20 Lakh</option>
								                    <option value="Rs.25 Lakh">Rs.25 Lakh</option>
								                    <option value="Rs.30 Lakh">Rs.30 Lakh</option>
								                    <option value="Rs.35 Lakh">Rs.35 Lakh</option>
								                    <option value="Rs.40 Lakh">Rs.40 Lakh</option>
								                    <option value="Rs.45 Lakh">Rs.45 Lakh</option>
								                    <option value="Rs.50 Lakh">Rs.50 Lakh</option>
								                    <option value="Rs.60 Lakh">Rs.60 Lakh</option>
								                    <option value="Rs.70 Lakh">Rs.70 Lakh</option>
								                    <option value="Rs.80 Lakh">Rs.80 Lakh</option>
								                    <option value="Rs.90 Lakh">Rs.90 Lakh</option>
								                    <option value="Rs.1 Crore">Rs.1 Crore</option>
								                    <option value="Rs.1 Crore & Above">Rs.1 Crore & Above</option>
								                  </select>
								                </div>
								                <div class="col-sm-2">
								                  <select class="form-control" name="income2" id="income2">
								                    <option  value="">Select</option>
								                    <option value="Monthly">Monthly</option>
								                    <option value="Annualy">Annualy</option>
								                  </select>
								                </div>
							                </div>

											
											<div class="form-group">
												<label for="inputEmail3" class="col-sm-2 control-label">Property</label>
								                <div class="col-sm-2">
								                  <select class="form-control" name="property" id="property" >
								                    <option value="-1" selected="selected">Any</option>
								                    <option value="Less than Rs.50 thousand">Less than Rs.50 thousand</option>
								                    <option value="Rs.50 thousand">Rs.50 thousand </option>
								                    <option value="Rs.1">Rs.1 Lakh</option>
								                    <option value="Rs.2">Rs.2 Lakh</option>
								                    <option value="Rs.3">Rs.3 Lakh</option>
								                    <option value="Rs.4">Rs.4 Lakh</option>
								                    <option value="Rs.5">Rs.5 Lakh</option>
								                    <option value="Rs.6">Rs.6 Lakh</option>
								                    <option value="Rs.7">Rs.7 Lakh</option>
								                    <option value="Rs.8">Rs.8 Lakh</option>
								                    <option value="Rs.9">Rs.9 Lakh</option>
								                    <option value="Rs.10">Rs.10 Lakh</option>
								                    <option value="Rs.12">Rs.12 Lakh</option>
								                    <option value="Rs.14">Rs.14 Lakh</option>
								                    <option value="Rs.16">Rs.16 Lakh</option>
								                    <option value="Rs.18">Rs.18 Lakh</option>
								                    <option value="Rs.20">Rs.20 Lakh</option>
								                    <option value="Rs.25">Rs.25 Lakh</option>
								                    <option value="Rs.30">Rs.30 Lakh</option>
								                    <option value="Rs.35">Rs.35 Lakh</option>
								                    <option value="Rs.40">Rs.40 Lakh</option>
								                    <option value="Rs.45">Rs.45 Lakh</option>
								                    <option value="Rs.50">Rs.50 Lakh</option>
								                    <option value="Rs.60">Rs.60 Lakh</option>
								                    <option value="Rs.70">Rs.70 Lakh</option>
								                    <option value="Rs.80">Rs.80 Lakh</option>
								                    <option value="Rs.90">Rs.90 Lakh</option>
								                    <option value="Rs.1">Rs.1 Crore</option>
								                    <option value="Rs.2">Rs.2 Crore</option>
								                    <option value="Rs.3">Rs.3 Crore</option>
								                    <option value="Rs.4">Rs.4 Crore</option>
								                    <option value="Rs.5">Rs.5 Crore</option>
								                    <option value="Rs.6">Rs.6 Crore</option>
								                    <option value="Rs.7">Rs.7 Crore</option>
								                    <option value="Rs.8">Rs.8 Crore</option>
								                    <option value="Rs.9">Rs.9 Crore</option>
								                    <option value="Rs.10">Rs.10 Crore</option>
								                    <option value="Rs.12">Rs.12 Crore</option>
								                    <option value="Rs.14">Rs.14 Crore</option>
								                    <option value="Rs.16">Rs.16 Crore</option>
								                    <option value="Rs.18">Rs.18 Crore</option>
								                    <option value="Rs.20">Rs.20 Crore</option>
								                    <option value="Rs.25">Rs.25 Crore</option>
								                    <option value="Rs.30">Rs.30 Crore</option>
								                    <option value="Rs.35">Rs.35 Crore</option>
								                    <option value="Rs.40">Rs.40 Crore</option>
								                    <option value="Rs.45">Rs.45 Crore</option>
								                    <option value="Rs.50">Rs.50 Crore</option>
								                    <option value="Rs.60">Rs.60 Crore</option>
								                    <option value="Rs.70">Rs.70 Crore</option>
								                    <option value="Rs.80">Rs.80 Crore</option>
								                    <option value="Rs.90">Rs.90 Crore</option>
								                    <option value="Rs.100">Rs.100 Crore</option> 
								                    <option value="Rs.100 Crore & Above">Rs.100 Crore & Above</option>
								                  </select>
								                </div>
								                <div class="col-sm-2">
								                  <select class="form-control" name="property2" id="property2">
								                    <option  value="">Select</option>
								                    <option value="Lakhs">Lakhs</option>
								                    <option value="Crores">Crores</option>
								                  </select>
								                </div> 
											</div>

											<h3>Family Details</h3>
											<hr>

											<div class="form-group">
								                <label for="inputEmail3" class="col-sm-2 control-label">Father Name</label>
								                <div class="col-sm-3">
								                  <input type="text" class="form-control" name="fathername" id="fathername" placeholder="Father Name" value="<?php echo set_value('fathername'); ?>">
								                </div>
								                <label for="inputPassword3" class="col-sm-2 control-label">Father Occupation</label>
								                <div class="col-sm-3">
								                  <input type="text" class="form-control" name="fdetails" id="fdetails" placeholder="Father details" value="<?php echo set_value('fdetails'); ?>">
								                </div>
							                </div>

							                <div class="form-group">
								                <label for="inputEmail3" class="col-sm-2 control-label">Mother Name</label>
								                <div class="col-sm-3">
								                  <input type="text" class="form-control" name="mothername" id="mothername" placeholder="Mother Name" value="<?php echo set_value('mothername'); ?>">
								                </div>
								                <label for="inputPassword3" class="col-sm-2 control-label">Mother Occupation</label>
								                <div class="col-sm-3">
								                  <input type="text" class="form-control" name="mdetails" id="mdetails" placeholder="Mother details" value="<?php echo set_value('mdetails'); ?>">
								                </div>
							                </div>

											<div class="form-group">
								                <label for="inputEmail3" class="col-sm-2 control-label">No. Of Brothers</label>
								                <div class="col-sm-3">
								                    <select class="form-control" name="nob" id="nob">
							                          <option value="0" <?php echo  set_select('nob', '0'); ?>>Select</option>
							                          <option value="none" <?php echo  set_select('nob', 'none'); ?>>none</option>
							                          <option value="1" <?php echo  set_select('nob', '1'); ?>>1</option>
							                          <option value="2" <?php echo  set_select('nob', '2'); ?>>2</option>
							                          <option value="3" <?php echo  set_select('nob', '3'); ?>>3</option>
							                          <option value="4" <?php echo  set_select('nob', '4'); ?>>4</option>
							                          <option value="5+" <?php echo  set_select('nob', '5+'); ?>>5+</option>
							                        </select>
								                </div>
								                <label for="inputPassword3" class="col-sm-2 control-label">No. Of Brothers Married</label>
								                <div class="col-sm-3">
								                  <select class="form-control" name="brosm" id="brosm">
						                            <option value="0" <?php echo  set_select('brosm', '0'); ?>>Select</option>
						                            <option value="none" <?php echo  set_select('brosm', 'none'); ?>>none</option>
						                            <option value="1" <?php echo  set_select('brosm', '1'); ?>>1</option>
						                            <option value="2" <?php echo  set_select('brosm', '2'); ?>>2</option>
						                            <option value="3" <?php echo  set_select('brosm', '3'); ?>>3</option>
						                            <option value="4" <?php echo  set_select('brosm', '4'); ?>>4</option>
						                            <option value="5+" <?php echo  set_select('brosm', '5+'); ?>>5+</option>
						                           </select>
								                </div>
							                </div>

							                <div class="form-group">
								                <label for="inputEmail3" class="col-sm-2 control-label">No. Of Sisters</label>
								                <div class="col-sm-3">
								                    <select class="form-control" name="nos" id="nos">
							                          <option value="0" <?php echo  set_select('nos', '0'); ?>>Select</option>
							                          <option value="none" <?php echo  set_select('nos', 'none'); ?>>none</option>
							                          <option value="1" <?php echo  set_select('nos', '1'); ?>>1</option>
							                          <option value="2" <?php echo  set_select('nos', '2'); ?>>2</option>
							                          <option value="3" <?php echo  set_select('nos', '3'); ?>>3</option>
							                          <option value="4" <?php echo  set_select('nos', '4'); ?>>4</option>
							                          <option value="5+" <?php echo  set_select('nos', '5+'); ?>>5+</option>
							                        </select>
								                </div>
								                <label for="inputPassword3" class="col-sm-2 control-label">No of Sisters married</label>
								                <div class="col-sm-3">
								                    <select class="form-control" name="sism" id="sism">
							                          <option value="0" <?php echo  set_select('sism', '0'); ?>>Select</option>
							                          <option value="none" <?php echo  set_select('sism', 'none'); ?>>none</option>
							                          <option value="1" <?php echo  set_select('sism', '1'); ?>>1</option>
							                          <option value="2" <?php echo  set_select('sism', '2'); ?>>2</option>
							                          <option value="3" <?php echo  set_select('sism', '3'); ?>>3</option>
							                          <option value="4" <?php echo  set_select('sism', '4'); ?>>4</option>
							                          <option value="5+" <?php echo  set_select('sism', '5+'); ?>>5+</option>
							                        </select>
								                </div>
							                </div>

											<div class="form-group">
												<label for="inputEmail3" class="col-sm-2 control-label">Address</label>
								                <div class="col-sm-5">
								                  <textarea name="address" class="form-control" id="inputDefault" rows="6"></textarea>
								                </div>
												
											</div>

                                            <h3>Photo Upload</h3>
											<hr>

                                            <div class="form-group">
								                <label for="inputPassword3" class="col-sm-2 control-label">Image Upload</label>
								                <div class="col-sm-3">
								                  <!--<input type="file" id="picone" name="userfile[]">-->
								                  <?php echo form_error('uploadedimages[]'); ?>
								                  <?php echo form_upload('uploadedimages[]','','multiple'); ?>
								                </div>
							                </div>


											
											<div class="form-group">
												<label class="col-md-3 control-label"></label>
												<div class="col-md-6 col-xs-11">
													<button type="submit"  class="btn btn-primary hidden-xs">Submit</button>
												</div>
											</div>											
										</form>
									</div>
								</section>
							</div>
						</div>


	<script type="text/javascript">

	    //Height Script// 

	      function roundit(which){
	        return Math.round(which*100)/100
	      }
	      
	      function roundit(which){
	        return Math.round(which*100)/100
	      }

	      function convercms(phval)
	      {
	      ///var cms= (phval/0.032808).toFixed(2);;

	      ///var cms= phval*30.48;

	      with (document.register_form){
	      cms=roundit(height.value*30.48);
	      document.getElementById('hgtcms').innerHTML =cms+" cms";

	      }
	      }

	      function convert_CMtoFT(cms)
	      {
	        var inch_val = Math.round(cms * 0.393701);
	        ///alert(inch_val);
	        var tot_inches = inch_val/12;
	        
	        var ft = Math.floor(tot_inches);
	        var inch_val = inch_val%12;
	        /*var str_tot_inch = tot_inches.toString();
	        var arr = str_tot_inch.split('.');
	        var ft = arr[0];
	        var inch = arr[1];
	        
	        var inch_dec = inch.substring(0,1);
	        var inches = new Number(inch_dec);
	        var inch_val = inches+1;*/
	        
	        
	        if(inch_val<10)
	        {
	          var ft_inch = ft+'.0'+inch_val;
	        }
	        
	        else 
	        {
	          var ft_inch = ft+'.'+inch_val;
	        }
	        ///var inch = Math.round(arr[1]);
	        
	         var heightlistbox = document.getElementById("height");
	       
	        for(var x=0;x < heightlistbox.length  ; x++)
	        {
	           
	           if(heightlistbox.options[x].value == ft_inch)
	           {
	        
	            heightlistbox.options[x].selected = true;
	            return ;
	           }
	        }
	      }

	      function convert_FTtoCM(ip)
	      {
	        var arr = ip.split('.');
	        var ft = arr[0];
	        var inch = arr[1];
	        var f_dig = inch.substring(0,1);
	        if(f_dig==0)
	        {
	          inch = inch.substring(1);
	        }
	        var inches = new Number(inch);
	        var tot_inch = (12*ft )+ inches;
	        ///alert(ft+'--'+inch+'--'+tot_inch);
	        var cms = tot_inch * 2.54;
	        cms = Math.round(cms);
	        
	        ///alert(cms);
	        
	         var cmslistbox = document.getElementById("CMS")
	       
	        for(var x=0;x < cmslistbox.length  ; x++)
	        {
	           
	           if(cmslistbox.options[x].value == cms)
	           {
	        
	            cmslistbox.options[x].selected = true;
	            return ;
	           }
	        }
	      }
	      
	      
	    //Ends Height Script// 


	    // States Select Option Starts//

	    function ajaxFunction(){
	      var country = document.getElementById("country").value;
	      //alert(country);
	      $.ajax({
	      type: "POST",
	      url: '<?php echo site_url("admin/ajaxcountry")?>',
	      data: {country:country},
	      success: function(res) {
	      //alert(res); 
	      $('#states').html(res);
	      }
	      });  
	    }

	    // States Select Option Ends//

	    // districts Select Option Starts//


	    function ajaxState(){
	        var state = document.getElementById("states").value;
	        //alert(state);
	        $.ajax({
	      type: "POST",
	      url: '<?php echo site_url("admin/ajaxstates")?>',
	      data: {state:state},
	      success: function(res) {
	      //alert(res); 
	      $('#districts').html(res);
	      }
	      });  
	    }

	    // district Select Option Ends//

	    // mandal select option starts //

	    function ajaxMandals()
	    {
	        var district = document.getElementById("districts").value;
	        //alert(district);
	        $.ajax({
		      type: "POST",
		      url: '<?php echo site_url("admin/ajaxmandals")?>',
		      data: {district:district},
		      success: function(res) {
		      //alert(res); 
		      $('#mandals').html(res);
		      }
		    });  
	    }

	    // mandal select option ends //

	    // birthstar select option starts //
        
         function getAjaxRaasi(birthstar)
	      {
	        //alert(birthstar);
	        $.get("ajax_get_raasi1",{ birth_star_id:birthstar },function(response){
	        var raasi=response.trim();
	        var raasilistbox=document.getElementById("raasi");
	        for(var x=0;x < raasilistbox.length; x++)
	        {  
	          if(raasilistbox.options[x].value==raasi)
	          {
	            raasilistbox.options[x].selected = true;
	            return ;
	          }
	        }
	        });
	      }



	    // birthstar select option ends //

	    // education select option starts //

	    function ajaxEducation()
	    {
	      var edtype = document.getElementById("edtype").value;
	      
	      //alert(edtype);
	      $.ajax({
	      type: "POST",
	      url: '<?php echo site_url("admin/ajaxeducation")?>',
	      data: {
	             edtype:edtype
	             
	            },
	      success: function(res) {
	      //alert(res); 
	      $('#education').html(res);
	      }
	      }); 
	    }

	    

	    // education select option ends //

	    // hiding fields //

	    function hideFields()
	    {
	    	var religion=$("#religion").val();
	    	//alert(religion);
	    	if(religion=='Christian' || religion=='Muslim - Shia' || religion=='Muslim - Sunni' || religion=='Muslim - Others')
	    	{
                 $('#hgothram').hide();
                 $('#hbstar').hide();
                 $('#hpadam').hide();
	    	}else{
	    		$('#hgothram').show();
                $('#hbstar').show();
                $('#hpadam').show();
	    	}
	    }

	    // hiding fields //

	    // check email id is available starts //

	    function check_email()
	    {
	        var lemail=$("#email").val();
	        //alert(lemail);
	        $.ajax({
	        type: "POST",
	        url: '<?php echo site_url("admin/checkemail")?>',
	        data: {lemail:lemail},
	        success: function(res) {
	        //alert(res); 
	        $('#email').html(res);
	        }
	        });  

	        
	    }

	    // check email id is available ends // 




	</script>
						
								
<?php
 include 'footer.php'; 

 ?>