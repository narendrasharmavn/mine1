<?php
class payment_config{
	var $Url = "https://paynetzuat.atomtech.in/paynetz/epi/fts";
	var $Login="160";
	var $Password="Test@123";
	var $MerchantName="ATOM";
	var $TxnCurr="INR";
	var $TxnScAmt="0";
}
?>