<!-- Vendor -->
		<script src="<?php echo base_url(); ?>assets/assets/vendor/jquery/jquery.js"></script>
		<script src="<?php echo base_url(); ?>assets/assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
		<script src="<?php echo base_url(); ?>assets/assets/vendor/bootstrap/js/bootstrap.js"></script>
		<script src="<?php echo base_url(); ?>assets/assets/vendor/nanoscroller/nanoscroller.js"></script>
		<script src="<?php echo base_url(); ?>assets/assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
		<script src="<?php echo base_url(); ?>assets/assets/vendor/magnific-popup/magnific-popup.js"></script>
		<script src="<?php echo base_url(); ?>assets/assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>
		<script src="<?php echo base_url(); ?>assets/assets/javascripts/tables/examples.datatables.row.with.details.js"></script>
		<!-- Specific Page Vendor -->
		<script src="<?php echo base_url(); ?>assets/assets/vendor/jquery-autosize/jquery.autosize.js"></script>
		<script src="<?php echo base_url(); ?>assets/assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.js"></script>

		<script src="<?php echo base_url(); ?>assets/assets/vendor/select2/select2.js"></script>
		<script src="<?php echo base_url(); ?>assets/assets/vendor/jquery-datatables/media/js/jquery.dataTables.js"></script>
		<script src="<?php echo base_url(); ?>assets/assets/vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js"></script>
		<script src="<?php echo base_url(); ?>assets/assets/vendor/jquery-datatables-bs3/assets/js/datatables.js"></script>
		
		<!-- Theme Base, Components and Settings -->
		<script src="<?php echo base_url(); ?>assets/assets/javascripts/theme.js"></script>
		
		<!-- Theme Custom -->
		<script src="<?php echo base_url(); ?>assets/assets/javascripts/theme.custom.js"></script>
		
		<!-- Theme Initialization Files -->
		<script src="<?php echo base_url(); ?>assets/assets/javascripts/theme.init.js"></script>

		<!-- Examples -->
		<script src="<?php echo base_url(); ?>assets/assets/javascripts/tables/examples.datatables.default.js"></script>
		<script src="<?php echo base_url(); ?>assets/assets/javascripts/tables/examples.datatables.row.with.details.js"></script>
		<script src="<?php echo base_url(); ?>assets/assets/javascripts/tables/examples.datatables.tabletools.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>

	</body>
</html>